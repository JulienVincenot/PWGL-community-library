#!/bin/sh

/usr/local/bin/neato -Tgif $1 > $2


